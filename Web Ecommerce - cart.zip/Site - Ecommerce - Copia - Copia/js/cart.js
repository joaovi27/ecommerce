// array com produtos e suas informações
const product = [
    {
        id: 0,
        image: './imagens/airmax.webp',
        title: 'Air Max',
        categoria: 'Calçados',
        descricao: 'Numeração de 32 a 44',
        price: 319,
    },
    {
        id: 1,
        image: './imagens/t1.jpg',
        title: 'Air Force',
        categoria: 'Calçados',
        descricao: 'Numeração de 35 a 42',
        price: 199,
    },
    {
        id: 2,
        image: './imagens/jordan.jpg',
        title: 'Air Jordan',
        categoria: 'Calçados',
        descricao: 'Numeração de 31 a 45',
        price: 479,
    },
    {
        id: 3,
        image: './imagens/cap.jfif',
        title: 'Chapéu StreetWear',
        categoria: 'Roupas',
        descricao: 'Tamanhos P, M e G',
        price: 149,
    }
    ,
    {
        id: 4,
        image: './imagens/tshirt.jpg',
        title: 'Camisa',
        categoria: 'Roupas',
        descricao: 'Tamanhos P, M, G e XX',
        price: 179,
    }
    ,
    {
        id: 5,
        image: './imagens/conjunto.jpg',
        title: 'Conjunto',
        categoria: 'Roupas',
        descricao: 'Tamanhos P, M, G e XX',
        price: 159,
    }
    ,
    {
        id: 6,
        image: './imagens/chuteira.jfif',
        title: 'Chuteira',
        categoria: 'Esportes',
        descricao: 'Numeração de 29 a 45',
        price: 249,
    }
    ,
    {
        id: 7,
        image: './imagens/ball.jpg',
        title: 'Bolas',
        categoria: 'Esportes',
        descricao: 'Diversas modalidades',
        price: 219,
    }
    ,
    {
        id: 8,
        image: './imagens/shoulder.jpg',
        title: 'Shoulder bags',
        categoria: 'Esportes',
        descricao: 'Diversos modelos',
        price: 209,
    }

];


const categories = [...new Set(product.map((item)=>
    {return item}))]
    let i=0;


document.getElementById('root').innerHTML = categories.map((item)=>
{
    var {image, title, categoria , descricao ,price} = item;

    // div cart
    return (

        `<div class='box' id='produtos'>
            <div class='img-box'>
                <img class='images' src=${image}></img>
            </div>

        <div class='cart-contain'>
      
        <div class="cards-tags"> 
        <span class="tag">${categoria}</span>
        </div>

        <div class="cards-tags"> 
        <p class='cards-title'>${title}</p>
        </div>

        <div class="cards-tags">  
        <ion-icon name="resize-outline"></ion-icon><!--icon-->
        <p class='cards-li'>${descricao}</p>
        </div>

        <div class="cards-tags"> 
        <h2 class='cards-price'>R$ ${price}.00</h2> 
        </div>`+
        "<button class='tag-2' onclick='addtocart("+(i++)+")'>Adicionar</button>"+
        
        `</div>
        </div>`
        
    )
}).join('')


var cart =[];

function addtocart(a){
    cart.push({...categories[a]});
    displaycart();
}
function delElement(a){
    cart.splice(a, 1);
    displaycart();
}

function displaycart(){
    let j = 0, total=0;
    document.getElementById("count").innerHTML=cart.length;
    if(cart.length==0){
        document.getElementById('cartItem').innerHTML = "Carrinho vazio";
        document.getElementById("total").innerHTML = "$ "+0+".00";
    }
    else{
        document.getElementById("cartItem").innerHTML = cart.map((items)=>
        {
            var {image, title, price} = items;
            total=total+price;
            document.getElementById("total").innerHTML = "$ "+total+".00";
            return(
                `<div class='cart-item'>
                <div class='row-img'>
                    <img class='rowimg' src=${image}>
                </div>
                <p style='font-size:12px;'>${title}</p>
            
                <h2 style='font-size: 15px;'>$ ${price}.00</h2>`+
                "<i class='fa-solid fa-trash' onclick='delElement("+ (j++) +")'></i></div>"
            );
        }).join('');
    }

    
}